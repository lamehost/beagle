__version__ = "0.1.0"
__author__ = "Marco Marzetti"
__author_email__ = "marco@lamehost.it"
__url__ = "https://github.com/lamehost/beagle"

