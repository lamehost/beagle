from __future__ import absolute_import

import importlib

from Exscript import Account
from Exscript.protocols import SSH2
from Exscript.protocols.exception import InvalidCommandException

from beagle.drivers.errors import CommandError, ConnectionError, LoginError


def get_driver(name):
    try:
        module = importlib.import_module(name)
        class_name = name.split('.')[-1].upper()
        obj = getattr(module, class_name)
        return obj
    except Exception, e:
        return False


class BeagleDriver(object):
    def __init__(self, **kwargs):
        self.hostname = kwargs.get('hostname', None)
        self.username = kwargs.get('username', None)
        self.password = kwargs.get('password', None)
        self.drivername = kwargs.get('drivername', None)
        self.username_prompt = kwargs.get('username_prompt', '[Uu]sername.*:')
        self.password_prompt = kwargs.get('password_prompt', '[Pp]assword.*:')
        self.findreplace = kwargs.get('findreplace', [])
        self.error_re = kwargs.get('error_re', None)
        self.timeout = kwargs.get('timeout', None)

        self.device = None

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc_value, exc_traceback):
        self.close()

    def sub(self, text):
        if not self.findreplace:
            return text

        result = list()
        for line in text.splitlines():
            for item in self.findreplace:
                try:
                    regex = re.compile(r'%s' % item['find'])
                except re.error:
                    continue
                matches = [
                    # start, end, dictionary with matches
                    [_.start(), _.end(), _.groupdict()]
                    for _ in regex.finditer(line)
                ]
                if matches:
                    oldend = 0
                    _ = list()
                    for start, end, groupdict, in matches:
                        # append from oldend (at first run equals to 0) up to the matched dict
                        _.append(line[oldend:start])
                        # replaces matches from groupdict with "replace"
                        # we have to replace boolean False matches (like None) with empty strings
                        _.append(item['replace'] % {k: (v or "") for k, v in groupdict.items()})
                        # oldend is equal to end
                        oldend = end
                    _.append(line[end:])
                    line = ''.join(_)
            result.append(line)

        return '\n'.join(result)

    def open(self, **kwargs):
        hostname = kwargs.get('hostname', self.hostname)
        username = kwargs.get('username', self.username)
        password = kwargs.get('password', self.password)
        drivername = kwargs.get('drivername', self.drivername)
        username_prompt = kwargs.get('username_prompt', self.username_prompt)
        password_prompt = kwargs.get('password_prompt', self.password_prompt)

        self.drivername = drivername
        self.hostname = hostname
        self.username = username
        self.password = password
        self.username_prompt = username_prompt
        self.password_prompt = password_prompt

        self.device = SSH2()
        self.device.set_driver(drivername)
        self.device.set_username_prompt(username_prompt)
        self.device.set_password_prompt(password_prompt)
        if self.error_re:
            self.device.set_error_prompt(self.error_re)
        else:
            self.error_re = self.device.get_error_prompt()

        if self.timeout:
            self.device.set_timeout(self.timeout)
        else:
            self.device.get_timeout()

        # Connect
        try:
            self.device.connect(hostname)
        except:
            raise ConnectionError(hostname)

        # Authenticate
        try:
            self.device._paramiko_auth_password(username, password)
        except:
            raise LoginError(hostname)
        self.device.proto_authenticated = True

        # Create a shell
        self.device._paramiko_shell()
        # Sync writer and listener
        self.device.expect(next(iter([_.pattern for _ in self.device.get_prompt()])))

        # Init terminal length and width
        self.device.autoinit()

        return self.device

    def close(self):
        try:
            self.device.send('exit\n')
            self.device.send('exit\n')
        except:
            pass
        self.device.close(force=True)

    def run(self, command, **kwargs):
        if not self.device or not self.device.proto_authenticated:
            self.open(**kwargs)

        try:
            self.device.execute(command)
            result = self.device.response
        except InvalidCommandException:
            raise CommandError(self.hostname, self.device.response)

        return self.sub(result)

    def ping(self, address, vrf='global', afi=1, safi=1, loopback=False):
        raise RuntimeError('Not implemented yet')

    def traceroute(self, address, vrf='global', afi=1, safi=1, loopback=False):
        raise RuntimeError('Not implemented yet')

    def show_route(self, address, vrf='global', afi=1, safi=1):
        raise RuntimeError('Not implemented yet')

    def show_bgp(self, address, vrf='global', afi=1, safi=1):
        raise RuntimeError('Not implemented yet')

    def show_bgp_neighbors(self, address, vrf='global', afi=1, safi=1):
        raise RuntimeError('Not implemented yet')

    def show_bgp_summary(self, vrf='global', afi=1, safi=1):
        raise RuntimeError('Not implemented yet')